#!/bin/bash

echo "🚀 Setting up Salesforce development environment..."

# Install Salesforce CLI
echo "📦 Installing Salesforce CLI..."
npm install -g @salesforce/cli

# Install development dependencies based on your package.json structure
echo "📦 Installing development tools..."
npm install -g prettier prettier-plugin-apex
npm install -g eslint
npm install -g husky lint-staged

# Install SFDX plugins that are commonly used
echo "🔌 Installing Salesforce CLI plugins..."
sf plugins install @salesforce/sfdx-scanner
sf plugins install @salesforce/lwc-dev-server

# Install project dependencies if package.json exists
if [ -f "package.json" ]; then
    echo "📦 Installing project dependencies..."
    npm install
fi

# Set up git configuration for better development experience
echo "⚙️ Configuring Git..."
git config --global init.defaultBranch main
git config --global pull.rebase false
git config --global core.autocrlf input

# Set up Prettier configuration based on your existing .prettierrc
echo "🎨 Setting up code formatting..."
if [ ! -f ".prettierrc" ]; then
    cat > .prettierrc << 'EOF'
{
  "trailingComma": "none",
  "plugins": ["prettier-plugin-apex", "@prettier/plugin-xml"],
  "overrides": [
    {
      "files": "**/lwc/**/*.html",
      "options": { "parser": "lwc" }
    },
    {
      "files": "*.{cmp,page,component}",
      "options": { "parser": "html" }
    }
  ],
  "tabWidth": 4,
  "printWidth": 80
}
EOF
fi

# Set up ESLint configuration for LWC if it doesn't exist
echo "🔍 Setting up linting..."
if [ ! -f "force-app/main/default/lwc/.eslintrc.json" ]; then
    mkdir -p force-app/main/default/lwc
    cat > force-app/main/default/lwc/.eslintrc.json << 'EOF'
{
  "extends": ["@salesforce/eslint-config-lwc/recommended"],
  "overrides": [
    {
      "files": ["*.test.js"],
      "rules": {
        "@lwc/lwc/no-unexpected-wire-adapter-usages": "off"
      },
      "env": {
        "node": true
      }
    }
  ]
}
EOF
fi

# Set up Jest configuration based on your existing setup
echo "🧪 Setting up testing framework..."
if [ ! -f "jest.config.js" ]; then
    cat > jest.config.js << 'EOF'
const { jestConfig } = require('@salesforce/sfdx-lwc-jest/config');

module.exports = {
    ...jestConfig,
    modulePathIgnorePatterns: ['<rootDir>/.localdevserver']
};
EOF
fi

# Create a basic sfdx-project.json if it doesn't exist
if [ ! -f "sfdx-project.json" ]; then
    echo "📋 Creating sfdx-project.json..."
    cat > sfdx-project.json << 'EOF'
{
  "packageDirectories": [
    {
      "path": "force-app",
      "default": true
    }
  ],
  "name": "salesforce-project",
  "namespace": "",
  "sfdcLoginUrl": "https://login.salesforce.com",
  "sourceApiVersion": "63.0"
}
EOF
fi

# Set up VS Code workspace settings
echo "⚙️ Setting up VS Code workspace..."
mkdir -p .vscode
if [ ! -f ".vscode/settings.json" ]; then
    cat > .vscode/settings.json << 'EOF'
{
  "search.exclude": {
    "**/node_modules": true,
    "**/bower_components": true,
    "**/.sfdx": true
  },
  "salesforcedx-vscode-core.show-cli-success-msg": false,
  "salesforcedx-vscode-core.push-or-deploy-on-save.enabled": true,
  "salesforcedx-vscode-core.push-or-deploy-on-save.preferDeployOnSave": true,
  "prettier.tabWidth": 4
}
EOF
fi

# Set up launch configuration for debugging
if [ ! -f ".vscode/launch.json" ]; then
    cat > .vscode/launch.json << 'EOF'
{
  "version": "0.2.0",
  "configurations": [
    {
      "name": "Launch Apex Replay Debugger",
      "type": "apex-replay",
      "request": "launch",
      "logFile": "${command:AskForLogFileName}",
      "stopOnEntry": true,
      "trace": true
    }
  ]
}
EOF
fi

# Make scripts executable
chmod +x .devcontainer/post-create.sh

# Final setup message
echo "✅ Salesforce development environment setup complete!"
echo ""
echo "🎯 Next steps:"
echo "1. Authenticate with Salesforce: sf org login web"
echo "2. Set default org: sf config set target-org your-org-alias"
echo "3. Start developing!"
echo ""
echo "📚 Useful commands:"
echo "  - sf org list                    # List connected orgs"
echo "  - sf project deploy start       # Deploy to org"
echo "  - sf project retrieve start     # Pull from org"
echo "  - npm run test:unit             # Run LWC tests"
echo "  - npm run prettier              # Format code"
echo ""
EOF
