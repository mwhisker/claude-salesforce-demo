# Salesforce Development Template

A complete development environment template for Salesforce projects with GitHub Codespaces.

## 🚀 Quick Start

1. **Use this template** to create a new repository
2. **Open in Codespace** - Click "Code" → "Codespaces" → "Create codespace"
3. **Wait for setup** - The devcontainer will install all dependencies (3-5 minutes)
4. **Authenticate**: `sf org login web --alias myorg`
5. **Set default org**: `sf config set target-org myorg`

## 📁 What's Included

- **DevContainer configuration** - Automatic environment setup
- **Salesforce CLI** with common plugins pre-installed
- **VS Code extensions** for Salesforce development
- **Code quality tools** - ESLint, Prettier, Jest
- **Standard project structure** - Ready for Salesforce development

## 🛠️ Available Commands

```bash
# Deploy to org
sf project deploy start

# Run tests
npm run test

# Format code
npm run prettier

# Validate code quality
npm run prettier:verify
```
